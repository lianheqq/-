#!/bin/bash
clear
echo "----------------源码安装vsftpd安装程序，按任意键继续----------------"	
get_char()
	{
	SAVEDSTTY=`stty -g`
	stty -echo
	stty cbreak
	dd if=/dev/tty bs=1 count=1 2> /dev/null
	stty -raw
	stty echo
	stty $SAVEDSTTY
	}
	echo ""
	echo "本安装为本地用户登录FTP，并开启日志，请按任意键继续......"
	char=`get_char`

mkdir -p /usr/local/man/man8/
mkdir -p /usr/local/man/man5/

tar zxvf vsftpd-2.3.4.tar.gz 
cd vsftpd-2.3.4
make
make install

cp vsftpd.conf /etc/
#touch /etc/vsftpd.chroot_list
touch /etc/ftpusers
cat >>/etc/ftpusers<<EOF
root
bin
daemon
adm
lp
sync
shutdown
halt
mail
news
uucp
operator
games
nobody
mysql
EOF

touch /var/log/vsftpd.log
cp RedHat/vsftpd.pam /etc/pam.d/vsftpd
cp ../vsftpd /etc/rc.d/init.d/
chmod 755 /etc/rc.d/init.d/vsftpd
chkconfig --add vsftpd
chkconfig  vsftpd on

sed -i 's#anonymous_enable=YES#anonymous_enable=NO#'  /etc/vsftpd.conf
sed -i 's\#local_enable=YES\local_enable=YES\g'  /etc/vsftpd.conf
sed -i 's\#write_enable=YES\write_enable=YES\g'  /etc/vsftpd.conf
sed -i 's\#local_umask=022\local_umask=022\g'  /etc/vsftpd.conf
sed -i 's\#ftpd_banner=Welcome to blah FTP service.\ftpd_banner=Welcome to xiaoyuwxzs FTP service.\g' /etc/vsftpd.conf
sed -i 's\dirmessage_enable=YES\#dirmessage_enable=YES\g' /etc/vsftpd.conf
sed -i 's\xferlog_enable=YES\#xferlog_enable=YES\g' /etc/vsftpd.conf
echo "dual_log_enable=YES" >>/etc/vsftpd.conf
echo "vsftpd_log_file=/var/log/vsftpd.log" >>/etc/vsftpd.conf
sed -i 's\connect_from_port_20=YES\#connect_from_port_20=YES\g' /etc/vsftpd.conf
echo "pam_service_name=vsftpd" >>/etc/vsftpd.conf
echo "chroot_local_user=YES" >>/etc/vsftpd.conf
echo "增加www用户组，并增加www用户，www家目录设为/home/wwwroot/"
sleep2 
groupadd www
useradd www -g www -d /home/wwwroot/ -s /sbin/nologin
echo "123654" | passwd --stdin www
chown www.www /home/wwwroot/
service vsftpd start
sleep 1
echo "删除安装临时文件.............."
rm -Rf vsftpd-2.3.4
echo 
echo
echo " ------------------- 如需增加新用户，请使用以下命令 -------------------"
echo "|      useradd 用户名 -g 用户组 -d 用户家目录 -s /sbin/nologin         |"
echo "|               如需禁用用户，增加用户名到 /etc/ftpusers               |"
sleep 1 
echo " -------------------------- vsftpd 安装结束! --------------------------"
echo 
echo
echo
echo



