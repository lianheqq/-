#!/bin/bash
clear
echo "---------------源码安装vsftpd卸载程序，按任意键继续----------------"
get_char()
        {
        SAVEDSTTY=`stty -g`
        stty -echo
        stty cbreak
        dd if=/dev/tty bs=1 count=1 2> /dev/null
        stty -raw
        stty echo
        stty $SAVEDSTTY
        }
        echo ""
        echo "确认卸载vsftpd，请按任意键继续......"
        char=`get_char`

service vsftpd stop
chkconfig --del vsftpd
rm -f /etc/rc.d/init.d/vsftpd
rm -f /usr/local/sbin/vsftpd
rm -f /etc/vsftpd.chroot_list
rm -f /etc/ftpusers
rm -f /var/log/vsftpd.log
rm -f /etc/pam.d/vsftpd
rm -f /etc/vsftpd.conf
rm -Rf /usr/local/man/man8/
rm -Rf /usr/local/man/man5/

echo "---------vsftpd卸载完成，未删除用户及其家目录，请手动删除-----------"
sleep 1
